USE YURTSYS;
SELECT * FROM PermanentStudent;