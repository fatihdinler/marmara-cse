USE YURTSYS;
SELECT * FROM MaintenanceRequest;