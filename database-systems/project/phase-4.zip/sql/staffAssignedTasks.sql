USE YURTSYS;
SELECT * FROM StaffAssignedTasks;