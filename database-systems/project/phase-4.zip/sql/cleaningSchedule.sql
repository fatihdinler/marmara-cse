USE YURTSYS;
SELECT * FROM CleaningSchedule;