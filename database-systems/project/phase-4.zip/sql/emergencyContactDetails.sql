USE YURTSYS;
SELECT * FROM EmergencyContactDetails;